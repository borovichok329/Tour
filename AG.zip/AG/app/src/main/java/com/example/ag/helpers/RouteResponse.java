package com.example.ag.helpers;

public class RouteResponse {
    public RouteResponseResult result;

    public RouteResponseResult getResult() {
        return result;
    }

    public void setResult(RouteResponseResult result) {
        this.result = result;
    }
}
