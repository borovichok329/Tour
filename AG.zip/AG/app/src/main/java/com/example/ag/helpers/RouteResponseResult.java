package com.example.ag.helpers;

import java.util.ArrayList;

public class RouteResponseResult {
    ArrayList<Route> records;

    public ArrayList<Route> getRecords() {
        return records;
    }

    public void setRecords(ArrayList<Route> records) {
        this.records = records;
    }
}
