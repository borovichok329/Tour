package com.example.ag.helpers;

public class Type {
}
