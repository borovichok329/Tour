package com.example.ag.helpers;

public class RoutesFilter {

    public String viewId = "service_provider_routes_listview";
    public int start = 0;
    public int limit = 50;
}
